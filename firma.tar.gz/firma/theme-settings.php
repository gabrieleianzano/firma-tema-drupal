<?php

/**
 * @file
 * Contains functions to alter the theme settings form for the Firma theme.
 */

use Drupal\Core\Form\FormStateInterface;
use Drupal\file\Entity\File;
use Drupal\file\Plugin\Core\Entity\FileInterface;

/**
 * Implements hook_form_system_theme_settings_alter().
 */
function firma_form_system_theme_settings_alter(&$form, FormStateInterface $form_state, $form_id = NULL) { // Check &
  if (isset($form_id)) {
    return;
  }

  $config = \Drupal::config('firma.settings');

  // === Contact Information Settings (Header) ===
  $form['firma_contact_settings'] = [
    '#type' => 'details',
    '#title' => t('Header Contact Information'),
    '#open' => TRUE,
    '#weight' => -10,
  ];
  $form['firma_contact_settings']['show_contact'] = [
    '#type' => 'checkbox',
    '#title' => t('Show Contact Info in Header'),
    '#default_value' => $config->get('show_contact'),
  ];
  $form['firma_contact_settings']['phone'] = [
    '#type' => 'textfield',
    '#title' => t('Phone Number (for Header)'),
    '#default_value' => $config->get('phone', '080 080 0990'),
    '#description' => t('Enter the contact phone number displayed in the header.'),
  ];
  $form['firma_contact_settings']['email'] = [
    '#type' => 'email',
    '#title' => t('E-mail Address (for Header)'),
    '#default_value' => $config->get('email', 'info@company.com'),
    '#description' => t('Enter the contact e-mail address displayed in the header.'),
  ];

  // === Social Media Links Settings (Header) ===
  $form['firma_social_settings'] = [
    '#type' => 'details',
    '#title' => t('Header Social Media Links'),
    '#open' => TRUE,
    '#weight' => -9,
  ];
  $form['firma_social_settings']['show_social_icon'] = [
    '#type' => 'checkbox',
    '#title' => t('Show Social Icons in Header'),
    '#default_value' => $config->get('show_social_icon'),
  ];
  $form['firma_social_settings']['facebook_url'] = [
    '#type' => 'textfield',
    '#title' => t('Facebook URL'),
    '#default_value' => $config->get('facebook_url'),
    '#description' => t('Enter the full URL (e.g., https://facebook.com/yourpage).'),
  ];
  $form['firma_social_settings']['twitter_url'] = [
    '#type' => 'textfield',
    '#title' => t('Twitter URL'),
    '#default_value' => $config->get('twitter_url'),
    '#description' => t('Enter the full URL (e.g., https://twitter.com/yourprofile).'),
  ];
  $form['firma_social_settings']['linkedin_url'] = [
    '#type' => 'textfield',
    '#title' => t('LinkedIn URL'),
    '#default_value' => $config->get('linkedin_url'),
    '#description' => t('Enter the full URL.'),
  ];
  $form['firma_social_settings']['instagram_url'] = [
    '#type' => 'textfield',
    '#title' => t('Instagram URL'),
    '#default_value' => $config->get('instagram_url'),
    '#description' => t('Enter the full URL.'),
  ];
  $form['firma_social_settings']['youtube_url'] = [
    '#type' => 'textfield',
    '#title' => t('YouTube URL'),
    '#default_value' => $config->get('youtube_url'),
    '#description' => t('Enter the full URL.'),
  ];
   $form['firma_social_settings']['rss_url'] = [
    '#type' => 'textfield',
    '#title' => t('RSS Feed URL'),
    '#default_value' => $config->get('rss_url'),
    '#description' => t('Enter the full URL for the RSS feed.'),
  ];

  // === Contact Page Settings ===
  $form['firma_contact_page_settings'] = [
    '#type' => 'details',
    '#title' => t('Contact Page Settings'),
    '#open' => TRUE,
    '#weight' => -8,
  ];
  $form['firma_contact_page_settings']['address'] = [
    '#type' => 'textfield',
    '#title' => t('Company Address'),
    '#default_value' => $config->get('address', '850 In luctus justo vel nisi, Duis mattis 10440'),
    '#description' => t('Enter the company address displayed on the contact page.'),
  ];
  $form['firma_contact_page_settings']['google_maps_embed_code'] = [
    '#type' => 'textarea',
    '#title' => t('Google Maps Embed Code'),
    // Updated default value with the user's provided iframe
    '#default_value' => $config->get('google_maps_embed_code', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3976.941777684485!2d-74.0831168857368!3d4.60418294380101!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNMKwMzYnMTUuMSJOIDc0wrAwNScwMS4xIlc!5e0!3m2!1sen!2sus!4v1617000000000!5m2!1sen!2sus" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>'),
    '#description' => t('Paste the full iframe embed code from Google Maps.'),
    '#rows' => 5,
  ];


  // === Slideshow Settings ===
  $form['firma_slideshow_settings'] = [
    '#type' => 'details',
    '#title' => t('Front Page Slideshow'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
    '#weight' => -7,
  ];
  $form['firma_slideshow_settings']['show_slideshow'] = [
    '#type' => 'checkbox',
    '#title' => t('Show Slideshow on Front Page'),
    '#default_value' => $config->get('show_slideshow'),
  ];
  $form['firma_slideshow_settings']['no_of_slides'] = [
    '#type' => 'number',
    '#title' => t('Number of Slides'),
    '#min' => 0,
    '#step' => 1,
    '#default_value' => $config->get('no_of_slides') ?: 3,
    '#description'  => t("Enter the number of slides required & Save configuration. Clear caches after changing this."), // Check &
  ];
  $form['firma_slideshow_settings']['slideshow_autoplay'] = [
    '#type' => 'checkbox',
    '#title' => t('Autoplay Slideshow'),
    '#default_value' => $config->get('slideshow_autoplay'),
  ];
  $form['firma_slideshow_settings']['slideshow_animation'] = [
    '#type' => 'select',
    '#title' => t('Slideshow Animation'),
    '#default_value' => $config->get('slideshow_animation', 'slide'),
    '#options' => [ 'slide' => t('Slide'), 'fade' => t('Fade'), 'scale' => t('Scale'), 'pull' => t('Pull'), 'push' => t('Push'), ],
  ];
  $form['firma_slideshow_settings']['slideshow_ratio'] = [
    '#type' => 'textfield',
    '#title' => t('Slideshow Ratio (width:height)'),
    '#default_value' => $config->get('slideshow_ratio'),
    '#description'   => t("E.g., '16:9' or '7:3'. Leave empty for auto."),
  ];
  $no_of_slides = $form_state->getValue('no_of_slides', $config->get('no_of_slides') ?: 3);
  if ($no_of_slides > 0) {
      $form['firma_slideshow_settings']['slides'] = [
        '#type' => 'details',
        '#title' => t('Slide Details'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
      ];
      for ($i = 1; $i <= $no_of_slides; $i++) {
        $form['firma_slideshow_settings']['slides']['slide' . $i] = [
          '#type' => 'details',
          '#title' => t('Slide @num', ['@num' => $i]),
          '#collapsible' => TRUE,
          '#collapsed' => TRUE,
        ];
        $form['firma_slideshow_settings']['slides']['slide' . $i]['slide_image_path' . $i] = [
          '#type' => 'managed_file',
          '#title' => t('Image'),
          '#default_value' => $config->get('slide_image_path'.$i),
          '#upload_location' => 'public://slideshow/',
          '#upload_validators' => [ 'file_validate_extensions' => ['gif png jpg jpeg'], ],
          '#description' => t('Upload an image file. Leave empty if using URL below.'),
        ];
        // Campo URL immagine (alternativo al caricamento diretto)
        $form['firma_slideshow_settings']['slides']['slide' . $i]['slide_image_url_' . $i] = [
          '#type' => 'textfield',
          '#title' => t('🌐 Image URL (alternative) - USE THIS INSTEAD'),
          '#default_value' => $config->get('slide_image_url_' . $i),
          '#description' => t('<strong>RECOMMENDED:</strong> Insert the URL of an image (e.g., https://example.com/image.jpg or /sites/default/files/slideshow/image.jpg). <strong>If you fill this field, the file upload above will be completely ignored.</strong>'),
          '#attributes' => [
            'placeholder' => 'https://example.com/image.jpg',
          ],
          '#weight' => -1, // Metti prima del campo upload
        ];
        $form['firma_slideshow_settings']['slides']['slide' . $i]['slide_title_' . $i] = [
          '#type' => 'textfield',
          '#title' => t('Title'),
          '#default_value' => $config->get('slide_title_' . $i),
        ];
        $form['firma_slideshow_settings']['slides']['slide' . $i]['slide_description_' . $i] = [
          '#type' => 'textarea',
          '#title' => t('Description'),
          '#default_value' => $config->get('slide_description_' . $i),
        ];
      }
  }


  // === Footer Settings ===
  $form['firma_footer_settings'] = [
      '#type' => 'details',
      '#title' => t('Footer Settings'),
      '#open' => TRUE,
      '#weight' => -6,
  ];
  $form['firma_footer_settings']['show_credit_link'] = [
      '#type' => 'checkbox',
      '#title' => t('Show Theme Credit Link in Footer'),
      '#default_value' => $config->get('show_credit_link'),
  ];

  // Add submit handler
  $form['#submit'][] = 'firma_settings_submit';
}

/**
 * Submit handler for theme settings form.
 * Salva SOLO il campo URL in un campo separato.
 */
function firma_settings_submit($form, FormStateInterface $form_state) {
  $no_of_slides = $form_state->getValue('no_of_slides', \Drupal::config('firma.settings')->get('no_of_slides') ?: 3);
  $fileStorage = \Drupal::entityTypeManager()->getStorage('file');
  $file_usage = \Drupal::service('file.usage');
  $config = \Drupal::configFactory()->getEditable('firma.settings');

  for ($i = 1; $i <= $no_of_slides; $i++) {
    // Salva il campo URL (se presente) in un campo SEPARATO
    $image_url = $form_state->getValue(['slides', 'slide' . $i, 'slide_image_url_' . $i]);
    if (!empty($image_url)) {
      $config->set('slide_image_url_' . $i, $image_url);
    } else {
      $config->clear('slide_image_url_' . $i);
    }
    
    // Gestisci il file caricato NORMALMENTE (non lo tocchiamo)
    $image_fids = $form_state->getValue(['slides', 'slide'.$i, 'slide_image_path'.$i]);
    if (!empty($image_fids[0])) {
      $file = $fileStorage->load($image_fids[0]);
      if ($file instanceof \Drupal\file\FileInterface && !$file->isPermanent()) {
        $file->setPermanent();
        $file->save();
        $file_usage->add($file, 'firma', 'theme_settings', 1);
      }
    }
  }
  
  $config->save();
}